package scene;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.awt.Color;

import elements.AmbientLight;
import elements.Camera;
import geometries.Geometry;

public class Scene {
	private String sceneName;
	private Color background;
	private AmbientLight ambientlight;
	private List<Geometry> geometries;
	private Camera camera;
	private double screenDistance;
	// ***************** Constructors ********************** //

	public Scene(String sceneName, Color background, Color ambientlight, double ka, List<Geometry> geometries,
			double screenDistance) {
		setSceneName(sceneName);
		this.background = background;
		this.ambientlight = new AmbientLight(ambientlight, ka);
		this.geometries = new ArrayList<Geometry>(geometries);
		this.camera = new Camera();
		setScreenDistance(screenDistance);
	}

	public Scene(Scene s) {
		setSceneName(s.sceneName);
		background = s.getBackground();
		this.ambientlight = new AmbientLight(s.getAmbientlight());
		this.geometries = new ArrayList<Geometry>(s.getGeometries());
		this.camera = new Camera(s.getCamera());
		setScreenDistance(s.screenDistance);
	}

	public Scene() {
		setSceneName(null);
		background = Color.BLACK;
		this.ambientlight = new AmbientLight();
		this.geometries = new ArrayList<Geometry>();
		this.camera = new Camera();
		setScreenDistance(100);
	}

	// ***************** Getters/Setters ********************** //
	public String getSceneName() {
		return sceneName;
	}

	public void setSceneName(String sceneName) {
		this.sceneName = sceneName;
	}

	public Color getBackground() {
		return background;
	}

	public void setBackground(Color background) {
		this.background = background;
	}

	public List<Geometry> getGeometries() {
		return geometries;
	}

	public void setGeometries(List<Geometry> geometries) {
		this.geometries = geometries;
	}

	public Camera getCamera() {
		return camera;
	}

	public void setCamera(Camera camera) {
		this.camera = camera;
	}

	public double getScreenDistance() {
		return screenDistance;
	}

	public void setScreenDistance(double screenDistance) {
		this.screenDistance = screenDistance;
	}

	public AmbientLight getAmbientlight() {
		return ambientlight;
	}

	public void setAmbientlight(AmbientLight ambientlight) {
		this.ambientlight = ambientlight;
	}
	// ***************** Operations ******************** //

	public void addGeometry(Geometry geometry) {
		geometries.add(geometry);
	}

	public Iterator<Geometry> getGeometriesIterator() {
		return geometries.iterator();
	}

	public void clearAllGeometry() {
		geometries.clear();
	}


}

