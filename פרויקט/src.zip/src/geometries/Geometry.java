package geometries ;
import java.util.List;

import primitives.Point3D;
import primitives.Ray;
import primitives.Vector;

public abstract class Geometry

{
	public Geometry() {}
	
	public abstract Vector getNormal(Point3D point) throws Exception;

	public abstract List<Point3D> FindIntersections (Ray r) throws Exception;
	
	
	
}