package geometries;
import java.util.ArrayList;
import java.util.List;

import primitives.Point3D;
import primitives.Ray;
import primitives.Vector;

public class Plane{
	private Vector normal;
	private Point3D p1;
	// ***************** Constructors ********************** //
	public Plane(){
		normal=new Vector();
		p1=new Point3D();
	}
	public Plane (Plane plane){
		this.normal=new Vector(plane.getNormal());
		this.p1=new Point3D(plane.getQ());
	}
	public Plane (Vector normal, Point3D q){
		this.normal=new Vector(normal);
		this.p1=new Point3D(q);
	}
	// ***************** Getters/Setters ********************** //
	public Vector getNormal() {
		return new Vector(normal);
	}
	public void setNormal(Vector normal) {
		this.normal = normal;
	}
	public Point3D getQ() {
		return new Point3D(p1);
	}
	public void setQ(Point3D q) {
		p1 = q;
	}
	// ***************** Operations ******************** //
	public Vector getNormal(Point3D point) {
		return normal;
	
    }
    
	public List<Point3D> FindIntersections(Ray ray){
		 List<Point3D> IntersectionssList =new ArrayList<Point3D>();
		 Point3D P=new Point3D(ray.getPoo());
		 Point3D distance = new Point3D(ray.getPoo());//P0-Q0//
		 distance.subtract(this.p1);
		 Vector vector=new Vector(distance);
		 Vector n = new Vector(normal);
		 n.scale(-1);
		 double mone=n.dotProduct(vector);
		 double mechane=normal.dotProduct(ray.getDirection());
		 Vector v=new Vector(ray.getDirection());
	     double t=(double)mone/mechane;  
		 if(t>0){
			 v.scale(t);
			 P.add(v.getHead());
			 IntersectionssList.add(P);
			
		 }
		
		 return IntersectionssList;
		
	}		
}


