package geometries;

import primitives.Point3D;
import primitives.Vector;

public abstract class Cylinder extends RadialGeometry 
		{
			
			private Point3D axisPoint;
			private Vector axisDirection;
			
	//***************** Constructors ********************** //
			
			public Cylinder(Point3D axisPoint,Vector axisDirection)
			{
				
			    axisPoint= new Point3D ();
				this.axisDirection= new Vector (axisDirection);
			}
			
			public Cylinder()
			{
				
				axisPoint=new Point3D();
				axisDirection=new Vector();
				
			}
			public Cylinder(Cylinder c)
			{
				
				//this.radius=Cylinder.radius;
				axisPoint=c.axisPoint;
				axisDirection=c.axisDirection;
			}
			
	// ***************** Getters/Setters ********************** //
			
			public Vector getAxisDirection()
			{
				return axisDirection;
			}
			
			public Point3D getAxisPoint()
			{
				
				return axisPoint;
			}
			
			public void setAxisDirection(Vector axisDirection)
			{
				
				this.axisDirection = axisDirection;
			}
			
			public void setAxisPoint(Point3D axisPoint)
			{
				
				this.axisPoint = axisPoint;
			}

			
@Override
	//***************** Administration  ******************** // 

		public String toString(){
	
			return " the Cylinder is: "+this.axisPoint+" the Direction is: "+axisDirection+this.toString()+"  /n";
		}


}