/*package elements;

import java.awt.Color;

import primitives.Point3D;

public class AmbientLight 
{
	Color _color;
	double _ka;
	
// ***************** Constructors ********************** //

 public AmbientLight() 	
 {
	_color=new Color(255,255,255);
	this._ka=1.0;
 }
 public AmbientLight(Color color, double ka)
 {
	 this.set_color(color);
	   this.setKa(ka);
 }

 public AmbientLight(AmbientLight _A)
 {
	 this.set_color(_A._color);
	 this.setKa(_A._ka);
 }
 public AmbientLight(int r,int g,int b)
 {
	   this._color = new Color(r,g,b);
	   this.setKa(0.1);
}
 
 // ***************** Getters/Setters ********************** //
public Color get_color() 
{
	return _color;
}
public void set_color(Color _color)
{
	this._color = _color;
}
public double getKa() 
{
	return _ka;
}

public void setKa(double ka)
{
	_ka = ka;
}
 
@Override
public String toString()
{
	return super.toString();
}

@Override
public boolean equals(Object obj) 
{

	return super.equals(obj);
}


 public Color getIntensity(Point3D point)
 {
		return new Color(((int)(_color.getRed()*_ka)),((int)(_color.getGreen()*_ka)),((int)(_color.getBlue()*_ka)));
		  
 }
}*/

package elements;

import java.awt.Color;
import primitives.Point3D;

public class AmbientLight {
	private double Ka;
	private Color _color;
// ***************** Constructors ********************** // 
	public AmbientLight() {
		_color  = new Color(255,255,255);
		Ka = 1;
	}

	public AmbientLight(Color color,double ka) {
	   this.setColor(color);
	   this.setKa(ka);
	}
	public AmbientLight(AmbientLight ambientLight) {
	   this.setColor(ambientLight._color);
	   this.setKa(ambientLight.Ka);
	}
	public AmbientLight(int r,int g,int b) {
		   this._color = new Color(r,g,b);
		   this.setKa(0.1);
		}
// ***************** Getters/Setters ********************** //
	public Color getColor() {
		return _color;
	}

	public void setColor(Color color)
	{
		this._color = color;
	}

	public double getKa() {
		return Ka;
	}

	public void setKa(double ka) {
		Ka = ka;
	}
// ***************** Operations ******************** //
	public Color getIntensity(Point3D point){
		return new Color(((int)(_color.getRed()*Ka)),((int)(_color.getGreen()*Ka)),((int)(_color.getBlue()*Ka)));
		  
  }

	

}

