/*package elements;
	
import primitives.Point3D;
import primitives.Ray;
import primitives.Vector;

	
	public class Camera 
	{
	private Point3D P0;
	private Vector Vup;
	private Vector Vright;
	private Vector Vtoward;
	//***************** Constructors ********************** //
	public Camera()
	{
		setP0(new Point3D(0,0,0));
		setVup(new Vector(0,1,0));
		setVtoward(new Vector(0,0,-1));
		this.Vright=new Vector(Vtoward.crossProduct(Vup));
	} 
	
	public Camera(Point3D _P0,Vector _Vup,Vector _Vtoward)                                     
	{
		this.P0=new Point3D(_P0);
		this.Vup=new Vector(_Vup);
		this.Vtoward=new Vector(_Vtoward);
		this.Vright=new Vector(Vtoward.crossProduct(Vup));
		
	}
	
	public Camera(Camera c)
	{

		this.P0=new Point3D(c.getP0());
		this.Vup=new Vector(c.getVup());
		this.Vright=new Vector(c.getVright());
		this.Vtoward=new Vector(c.getVtoward());
	}

	public Camera(Point3D P0, Vector _Vup, Vector _Vtoward, Vector Vright)
	{
		this.P0=new Point3D(P0);
		this.Vup=new Vector(_Vup);
		this.Vtoward=new Vector(_Vtoward);
		this.Vright=new Vector(Vright);
	}

	//***************** Getters/Setters ********************** //
	public Point3D getP0()
	{
		return P0;
	}
	public Vector getVright()
	{
		return Vright;
	}
	public Vector getVtoward() 
	{
		return Vtoward;
	}
	public Vector getVup() 
	{
		return Vup;
	}
	public void setP0(Point3D p0) 
	{
		P0 = p0;
	}
	public void setVright(Vector vright) 
	{
		Vright = vright;
	}
	public void setVtoward(Vector vtoward) 
	{
		Vtoward = vtoward;
	}
	public void setVup(Vector vup) 
	{
		Vup = vup;
	}
	
	
	
//	public Ray constructRayThroughPixel(int Nx, int Ny, double x, double y,double screenDist, double screenWidt, double screenHeight){
//		 Point3D pc= new Point3D(P0);
//		 Vector vTo=new Vector(Vtoward);
//		 vTo.scalarMult(screenDist);
//		 pc = new Point3D(pc.add(vTo.getHead()));
//		 double Rx=screenWidt/Nx;
//		 double Ry=screenHeight/Ny;
//		 Vector v_Right=new Vector(Vright);
//		 v_Right = new Vector(v_Right.scalarMult((x-Nx/2.0)*Rx + Rx/2.0));
//		 Vector v_Up=new Vector(Vup);
//		 v_Up = new Vector(v_Up.scalarMult((y-Ny/2.0)*Ry + Ry/2.0));
//		 v_Right = new Vector(v_Right.subV(v_Up));
//		 Point3D P= new Point3D(pc);
//		 P = new Point3D (P.add(v_Right.getHead()));
//		// System.out.println("Point"+P);
//		 Point3D other_p=new Point3D(P.subV(P0));
//		 Vector vector=new Vector(other_p);
//		 try 
//		 {
//			vector.normalize();
//		 }  
//		 catch (Exception e)
//		 {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		 }
//		 Ray ray= new Ray(P0, vector);
//			return ray;
//		 }

	public Ray constructRayThroughPixel(int Nx, int Ny, double x, double y,double screenDist, double screenWidt, double screenHeight){
	 Point3D pc= new Point3D(P0);
	 Vector vTo=new Vector(Vtoward);
	 vTo.scalarMult(screenDist);
	 pc.add(vTo.getHead());
	 double Rx=screenWidt/Nx;
	 double Ry=screenHeight/Ny;
	 Vector v_Right=new Vector(Vright);
	 v_Right.scalarMult((x-Nx/2.0)*Rx + Rx/2.0);
	 Vector v_Up=new Vector(Vup);
	 v_Up.scalarMult((y-Ny/2.0)*Ry + Ry/2.0);
	 v_Right.subV(v_Up);
	 Point3D P= new Point3D(pc);
	 P.add(v_Right.getHead());
	// System.out.println("Point"+P);
	 Point3D other_p=new Point3D(P);
	 other_p.subV(P0);
	 Vector vector=new Vector(other_p);
	 try {
		vector.normalize();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	 Ray ray= new Ray(P, vector);
		return ray;
	 }
	
	
	
	}*/
package elements;

import primitives.Point3D;
import primitives.Ray;
import primitives.Vector;

public class Camera {
	private Point3D P0=new Point3D(0,0,0) ;
	private Vector vUp;
	private Vector vToward;
    private	Vector vRight;
	// ***************** Constructors ********************** //
	public Camera(){	
      setP0(new Point3D(0,0,10));
      setvUp(new Vector(0,1,0));
      setvToward(new Vector(0,0,-1));
      setvRight(new Vector(getvToward().crossProduct(getvUp())));

	}
	public Camera (Camera camera){
		this.P0=new Point3D(camera.getP0());
		this.vUp=new Vector(camera.getvUp());
		this.vRight=new Vector(camera.getvRight());
		this.vToward=new Vector(camera.getvToward());
	}
	public Camera (Point3D P0, Vector vUp,Vector vToward ){
		this.P0=new Point3D(P0);
		this.vUp=new Vector(vUp);
		this.vToward=new Vector(vToward);
		this.vRight=new Vector(vToward.crossProduct(vUp));
			
	}
	// ***************** Getters/Setters ********************** //
	public Point3D getP0() {
		return P0;
	}
	public void setP0(Point3D p0) {
		P0 = p0;
	}
	public Vector getvUp() {
		return vUp;
	}
	public void setvUp(Vector vUp) {
		this.vUp = vUp;
	}
	public Vector getvRight() {
		return vRight;
	}
	public void setvRight(Vector vRight) {
		this.vRight = vRight;
	}
	public Vector getvToward() {
		return vToward;
	}
	public void setvToward(Vector vToward) {
		this.vToward = vToward;
	}
	// ***************** Administration ********************** //
	@Override
	public String toString(){
		return "Vto: "   + vToward + "\n" +   "Vup: "   + vUp + "\n" +  "Vright:" + vRight  +  ".";   
	}
	// ***************** Operations ******************** //

	public Ray constructRayThroughPixel(int Nx, int Ny, double x, double y,double screenDist, double screenWidt, double screenHeight){
	 Point3D pc= new Point3D(P0);
	 Vector vTo=new Vector(vToward);
	 vTo.scale(screenDist);
	 pc.add(vTo.getHead());
	 double Rx=screenWidt/Nx;
	 double Ry=screenHeight/Ny;
	 Vector v_Right=new Vector(vRight);
	 v_Right.scale((x-Nx/2.0)*Rx + Rx/2.0);
	 Vector v_Up=new Vector(vUp);
	 v_Up.scale((y-Ny/2.0)*Ry + Ry/2.0);
	 v_Right.subtract(v_Up);
	 Point3D P= new Point3D(pc);
	 P.add(v_Right.getHead());
	// System.out.println("Point"+P);
	 Point3D other_p=new Point3D(P);
	 other_p.subtract(P0);
	 Vector vector=new Vector(other_p);
	 try {
		vector.normalize();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	 Ray ray= new Ray(P, vector);
		return ray;
	 }
	
}

	 
	 
	 