package unitTests;

import java.awt.Color;

import org.junit.Test;

import renderer.ImageWriter;

public class ImageWriterTest {

	 @Test
	public void test() 
	{
	ImageWriter iw = new ImageWriter("Image1",500,500,1,1);
	for(int i=0; i<500;i++)
	for (int j =0;j<500 ;j++)
	{
	if(i%50==0 || j%50==0)
	iw.writePixel(i, j,Color.pink);
	else
	iw.writePixel(i, j, new Color(150,20,130));
	}
	iw.writeToimage();
	}

}

