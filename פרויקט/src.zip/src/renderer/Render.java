package renderer;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import geometries.Geometry;
import primitives.Point3D;
import primitives.Ray;
import scene.Scene;

public class Render {
	private Scene _scene;
	private ImageWriter imageWriter;

	// ***************** Getters/Setters ********************** //

	public Scene getScene() {
		return _scene;
	}

	public void setScene(Scene scene) {
		this._scene = scene;
	}

	public ImageWriter getImageWriter() {
		return imageWriter;
	}

	public void setImageWriter(ImageWriter imageWriter) {
		this.imageWriter = imageWriter;
	}

	// ***************** Constructors ********************** // 

	public Render() {
		this._scene = new Scene();
		this.imageWriter = new ImageWriter("image", 3, 3, 3, 3);
	}

	public Render(Scene s, ImageWriter i) {
		_scene = new Scene(s);
		imageWriter = i;
	}

	public Render(String name, int width, int height, String name2, Color b, Color a, double ka, List<Geometry> g,
		int color	)// double d
	{
		imageWriter = new ImageWriter(name, width, height, width, height);
		_scene = new Scene(name2, b, a, ka, g, color);
	}

	public void renderImage() throws Exception {
		List<Point3D> intersectionPoints = new ArrayList<Point3D>();
		Point3D closestPoint = new Point3D();
		for (int i = 0; i < imageWriter.getHeight(); i++)
			for (int j = 0; j < imageWriter.getWidth(); j++) {
				Ray ray = _scene.getCamera().constructRayThroughPixel(imageWriter.getNx(), imageWriter.getNy(), j, i,
						_scene.getScreenDistance(), imageWriter.getWidth(), imageWriter.getHeight());
				intersectionPoints = getSceneRayIntersectios(ray);//?
				if (intersectionPoints.isEmpty())
					imageWriter.writePixel(j, i, _scene.getBackground());
				else {
					closestPoint = getClosestPoint(intersectionPoints);
					imageWriter.writePixel(j, i, calcColor(closestPoint));
				}
			}
	}

	public void printGrid(double interval) {
		// printGrid(interval);
		for (int i = 0; i < imageWriter.getHeight(); i++)
			for (int j = 0; j < imageWriter.getWidth(); j++)
				if (i % interval == 0 || j % interval == 0)
					imageWriter.writePixel(i, j, new Color(255, 255, 255));
	}

	public Color calcColor(Point3D p) {
		return _scene.getAmbientlight().getIntensity(p);
	}

	public Point3D getClosestPoint(List<Point3D> lp) {
		double distance = Double.MAX_VALUE;
		Point3D P0 = _scene.getCamera().getP0();
		Point3D minDistancePoint = null;

		for (Point3D point : lp) {
			if (P0.distance(point) < distance) {
				minDistancePoint = new Point3D(point);
				distance = P0.distance(point);
			}
		}
		return minDistancePoint;
	}

	private List<Point3D> getSceneRayIntersectios(Ray ray) throws Exception {
		Iterator<Geometry> geometries = _scene.getGeometriesIterator();
		List<Point3D> intersectionPoints = new ArrayList<Point3D>();
		List<Point3D> geometryIntersectionPoints = new ArrayList<Point3D>(0);
		Geometry geometry;
		while (geometries.hasNext()) {
			geometry = geometries.next();

			try {
				geometryIntersectionPoints = geometry.FindIntersections(ray);

			} catch (Exception e) {

				e.printStackTrace();
				return new ArrayList<Point3D>();
			}
			if (geometryIntersectionPoints != null)
				for (int i = 0; i < geometryIntersectionPoints.size(); i++) {
					intersectionPoints.add(geometryIntersectionPoints.get(i));
				}
		}
		return intersectionPoints;
	}
}




